package farm.inventory;

import farm.core.FailedTransactionException;
import farm.core.InvalidStockRequestException;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class BasicInventoryTest {
    private BasicInventory inventory;

    @Before
    public void setUp() {
        inventory = new BasicInventory();
    }

    @Test
    public void testAddProductSuccessfullyAddsProduct() {
        inventory.addProduct(Barcode.EGG, Quality.REGULAR);
        assertTrue(inventory.existsProduct(Barcode.EGG));
        Product product = inventory.getAllProducts().get(0);
        assertEquals(Barcode.EGG, product.getBarcode());
        assertEquals(Quality.REGULAR, product.getQuality());
    }

    @Test
    public void testAddProductWithQuantityThrowsInvalidStockRequestException() {
        InvalidStockRequestException thrown = null;
        try {
            inventory.addProduct(Barcode.EGG, Quality.REGULAR, 2);
        } catch (InvalidStockRequestException e) {
            thrown = e;
        }
        assertNotNull("Expected InvalidStockRequestException to be thrown", thrown);
        assertEquals("Current inventory is not fancy enough. Please supply products one at a time.", thrown.getMessage());
    }

    @Test
    public void testExistsProductAfterAddingAndRemoving() {
        assertFalse(inventory.existsProduct(Barcode.MILK));
        inventory.addProduct(Barcode.MILK, Quality.REGULAR);
        assertTrue(inventory.existsProduct(Barcode.MILK));
        inventory.removeProduct(Barcode.MILK);
        assertFalse(inventory.existsProduct(Barcode.MILK));
    }

    @Test
    public void testRemoveProductSuccessfullyRemovesProduct() {
        inventory.addProduct(Barcode.JAM, Quality.REGULAR);
        List<Product> removed = inventory.removeProduct(Barcode.JAM);
        assertEquals(1, removed.size());
        assertEquals(Barcode.JAM, removed.get(0).getBarcode());
        assertFalse(inventory.existsProduct(Barcode.JAM));
    }

    @Test
    public void testRemoveNonExistentProductReturnsEmptyList() {
        List<Product> removed = inventory.removeProduct(Barcode.BREAD);
        assertTrue(removed.isEmpty());
    }

    @Test
    public void testRemoveProductWithQuantityThrowsFailedTransactionException() {
        FailedTransactionException thrown = null;
        try {
            inventory.removeProduct(Barcode.JAM, 3);
        } catch (FailedTransactionException e) {
            thrown = e;
        }
        assertNotNull("Expected FailedTransactionException to be thrown", thrown);
        assertEquals("Current inventory is not fancy enough. Please purchase products one at a time.", thrown.getMessage());
    }

    @Test
    public void testGetAllProductsReturnsAllProducts() {
        inventory.addProduct(Barcode.WOOL, Quality.REGULAR);
        inventory.addProduct(Barcode.COFFEE, Quality.SILVER);
        List<Product> products = inventory.getAllProducts();
        assertEquals(2, products.size());
        assertTrue(products.stream().anyMatch(p -> p.getBarcode() == Barcode.WOOL && p.getQuality() == Quality.REGULAR));
        assertTrue(products.stream().anyMatch(p -> p.getBarcode() == Barcode.COFFEE && p.getQuality() == Quality.SILVER));
    }

    @Test
    public void testGetAllProductsWhenEmpty() {
        List<Product> products = inventory.getAllProducts();
        assertTrue(products.isEmpty());
    }

    @Test
    public void testGetAllProductsReturnsCopy() {
        inventory.addProduct(Barcode.WOOL, Quality.REGULAR);
        List<Product> products = inventory.getAllProducts();
        products.clear();
        assertEquals(1, inventory.getAllProducts().size());
    }

    @Test
    public void testAddAndRemoveMultipleSameProducts() {
        inventory.addProduct(Barcode.COFFEE, Quality.REGULAR);
        inventory.addProduct(Barcode.COFFEE, Quality.SILVER);
        assertEquals(2, inventory.getAllProducts().size());
        inventory.removeProduct(Barcode.COFFEE);
        assertEquals(1, inventory.getAllProducts().size());
        assertTrue(inventory.existsProduct(Barcode.COFFEE));
        inventory.removeProduct(Barcode.COFFEE);
        assertFalse(inventory.existsProduct(Barcode.COFFEE));
        assertTrue(inventory.getAllProducts().isEmpty());
    }

    @Test(expected = NullPointerException.class)
    public void testAddProductWithNullBarcodeThrowsException() {
        inventory.addProduct(null, Quality.REGULAR);
    }

    @Test(expected = NullPointerException.class)
    public void testAddProductWithNullQualityThrowsException() {
        inventory.addProduct(Barcode.EGG, null);
    }

    @Test(expected = NullPointerException.class)
    public void testExistsProductWithNullBarcodeThrowsException() {
        inventory.existsProduct(null);
    }

    @Test(expected = NullPointerException.class)
    public void testRemoveProductWithNullBarcodeThrowsException() {
        inventory.removeProduct(null);
    }
}
