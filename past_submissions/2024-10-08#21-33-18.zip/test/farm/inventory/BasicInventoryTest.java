package farm.inventory;

import farm.core.FailedTransactionException;
import farm.core.InvalidStockRequestException;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class BasicInventoryTest {
    private BasicInventory inventory;

    @Before
    public void setUp() {
        inventory = new BasicInventory();
    }

    // Existing tests...

    // Adjusted or removed null argument tests since they fail in the correct implementation

    @Test
    public void testRemoveProductRemovesOnlySpecifiedBarcode() {
        // Add products with different barcodes
        inventory.addProduct(Barcode.EGG, Quality.REGULAR);
        inventory.addProduct(Barcode.MILK, Quality.GOLD);
        inventory.addProduct(Barcode.BREAD, Quality.SILVER);

        // Remove the EGG product
        List<Product> removed = inventory.removeProduct(Barcode.EGG);
        assertEquals(1, removed.size());
        assertEquals(Barcode.EGG, removed.get(0).getBarcode());

        // Ensure MILK and BREAD are still in the inventory
        assertTrue(inventory.existsProduct(Barcode.MILK));
        assertTrue(inventory.existsProduct(Barcode.BREAD));
        assertFalse(inventory.existsProduct(Barcode.EGG));
    }

    @Test
    public void testRemoveNonExistentProductDoesNotAffectInventory() {
        // Add products to inventory
        inventory.addProduct(Barcode.MILK, Quality.REGULAR);
        inventory.addProduct(Barcode.BREAD, Quality.GOLD);

        // Attempt to remove a product not in the inventory
        List<Product> removed = inventory.removeProduct(Barcode.JAM);
        assertTrue(removed.isEmpty());

        // Verify that the inventory is unchanged
        assertTrue(inventory.existsProduct(Barcode.MILK));
        assertTrue(inventory.existsProduct(Barcode.BREAD));
        assertFalse(inventory.existsProduct(Barcode.JAM));
    }

    @Test
    public void testAddProductDoesNotThrowException() {
        try {
            inventory.addProduct(Barcode.EGG, Quality.REGULAR);
            // Verify that the product was added
            assertTrue(inventory.existsProduct(Barcode.EGG));
        } catch (Exception e) {
            fail("Adding a product should not throw an exception, but it threw: " + e);
        }
    }

    @Test
    public void testRemoveProductDoesNotThrowException() {
        inventory.addProduct(Barcode.MILK, Quality.REGULAR);
        try {
            List<Product> removed = inventory.removeProduct(Barcode.MILK);
            assertEquals(1, removed.size());
            assertEquals(Barcode.MILK, removed.get(0).getBarcode());
        } catch (Exception e) {
            fail("Removing an existing product should not throw an exception, but it threw: " + e);
        }
    }

    @Test
    public void testRemoveNonExistentProductDoesNotThrowException() {
        try {
            List<Product> removed = inventory.removeProduct(Barcode.JAM);
            assertTrue(removed.isEmpty());
        } catch (Exception e) {
            fail("Removing a non-existent product should not throw an exception, but it threw: " + e);
        }
    }

}
